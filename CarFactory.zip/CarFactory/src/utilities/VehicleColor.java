package utilities;

public interface VehicleColor {
    void applyColor();
}
