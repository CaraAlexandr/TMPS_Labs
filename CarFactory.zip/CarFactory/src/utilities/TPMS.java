package utilities;

public class TPMS {
    public double getTirePressure() {
        return 32.5; // Mocked data
    }
}
