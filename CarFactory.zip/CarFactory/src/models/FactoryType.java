package models;

public enum FactoryType {
    MOTORCYCLE,
    CAR,
    TRUCK
}

